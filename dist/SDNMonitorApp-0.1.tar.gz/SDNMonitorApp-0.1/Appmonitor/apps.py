from django.apps import AppConfig


class AppmonitorConfig(AppConfig):
    name = 'Appmonitor'
