from . import views
from ..utils import get_api_urls

urlpatterns = get_api_urls(views)
