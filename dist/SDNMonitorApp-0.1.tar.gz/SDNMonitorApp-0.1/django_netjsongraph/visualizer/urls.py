from . import views
from ..utils import get_visualizer_urls

urlpatterns = get_visualizer_urls(views)
