from django.apps import AppConfig


class TopologyConfig(AppConfig):
    name = 'topology'
